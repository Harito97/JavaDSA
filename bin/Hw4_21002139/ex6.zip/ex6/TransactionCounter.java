package Hw4_21002139.ex6;

import java.util.LinkedList;
import java.util.Queue;

public class TransactionCounter {
    private Customer beingServedCustomer;
    private LinkedList<Customer> servicedCustomer = new LinkedList<>();

    public int numberOfCustomerServiced() {
        return servicedCustomer.size();
    }

    public long averageTimeService() {
        if (servicedCustomer == null || servicedCustomer.size() == 0) {
            return 0;
        }
        long averageTimeService = 0;
        for (int i = 0; i < servicedCustomer.size(); i++) {
            averageTimeService += servicedCustomer.get(i).getTimeBeServicedInTransaction();
        }
        return averageTimeService / servicedCustomer.size() / 1000000;
    }

    public void getDoneACustomer() {
        if (beingServedCustomer == null) {
            beingServedCustomer = SystemService.getCustomers().poll();
            return;
        }
        servicedCustomer.add(beingServedCustomer);
        beingServedCustomer.getDone();

        beingServedCustomer = SystemService.getCustomers().poll();
        if (beingServedCustomer == null)
            return;
        beingServedCustomer.getCustomerToTransaction();
    }

    public String toStringInformation() {
        return "    Number Of Customer Serviced = " + numberOfCustomerServiced() + "\n    Average Time Service = "
                + averageTimeService() + "ms\n"; 
    }
}
