package Hw6_21002139_PhamNgocHai.ex1;

public interface Entry<K, E> {
    K getKey(); // K là khoá của phần tử

    E getValue(); // E là giá trị phần tử
    
}
