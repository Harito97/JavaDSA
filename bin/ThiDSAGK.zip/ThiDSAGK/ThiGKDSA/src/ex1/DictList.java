package ex1;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unchecked")
public class DictList<T> implements ListInterface<T>{
    List<T> list = new ArrayList<>();

    public DictList() {

    }
	
	@Override
	public void add(T data) {
	    // TODO Auto-generated method stub
		list.add(data);
	}

	@Override
	public T get(int i) {
		// TODO Auto-generated method stub
		return list.get(i);
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return list.isEmpty();
	}

    public int findWord(String word) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).equals(word)) {
                return i;
            }
        }
        return -1;
    }

}
