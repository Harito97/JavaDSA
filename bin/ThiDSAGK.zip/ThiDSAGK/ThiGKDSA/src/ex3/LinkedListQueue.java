package ex3;

import java.util.LinkedList;
import java.util.Queue;
 
@SuppressWarnings("unchecked")
public class LinkedListQueue<T>  implements QueueInterface<T>{

	// class Node {
	// 	T element;
	// 	Node next;
	// 	}
	
	Queue<T> myQueue = new LinkedList<>();

	@Override
	public void enqueue(T element) {
		// TODO Auto-generated method stub
		myQueue.add(element);
	}

	@Override
	public T dequeue() {
		// TODO Auto-generated method stub
		return myQueue.poll();
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return myQueue.isEmpty();
	}

}