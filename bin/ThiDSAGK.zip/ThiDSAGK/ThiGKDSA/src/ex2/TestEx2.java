package ex2;

public class TestEx2 {
    
}
