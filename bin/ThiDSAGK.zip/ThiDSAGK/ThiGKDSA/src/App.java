import java.util.Stack;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
        System.out.println(4+6);
    }
    public boolean isValidExpr(String expr)
    {
        Stack<Character> stack = new Stack<>();
        for (int i = 0; i < expr.length(); i++) {
            char character = expr.charAt(i);
            if (character == '(') {
                stack.push(character);
                continue;
            }

            if (!stack.isEmpty() && (character == ')' && stack.peek() == '(')) {
                stack.pop();
                continue;
            }

            if (character == ')') {
                stack.push(character);
                continue;
            }
        }

        if (stack.isEmpty()) {
            return true;
        }
        return false;
    }
}
