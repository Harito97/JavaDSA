package Hw4_21002139.ex6;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

// 1 truong hop ket qua khi chay chuong trinh neu khong co su xung dot du lieu

// Thoi gian SystemService phuc vu la: 60s
// Hay ngoi doi 60s de chung toi thu thap duoc du lieu thong ke :)

// Thread Khach den SystemService de duoc phuc vu is running.
// Thread Qua trinh phuc vu trong SystemService is running.

// So khach den SystemService la: 497
// So khach da duoc phuc vu la: 497

// Information of transaction counter 0 is: 
//     Number Of Customer Serviced = 114
//     Average Time Service = 84284ms

// Information of transaction counter 1 is: 
//     Number Of Customer Serviced = 161
//     Average Time Service = 127772ms

// Information of transaction counter 2 is: 
//     Number Of Customer Serviced = 260
//     Average Time Service = 86097ms

// Information of transaction counter 3 is: 
//     Number Of Customer Serviced = 281
//     Average Time Service = 85484ms

// Information of transaction counter 4 is: 
//     Number Of Customer Serviced = 476
//     Average Time Service = 33713ms

public class SystemService {
    private static int numberOfCustomerComeToSystemService;
    private static Random random = new Random();
    private static Queue<Customer> customers = new LinkedList<>();
    // private static int numberTransaction = random.nextInt(10) + 1; // create
    // random number transaction from 1 to 10
    static int numberTransaction = 5;
    private static TransactionCounter[] transactionCounters = new TransactionCounter[numberTransaction];
    private static Object lock = new Object(); // object for synchronization

    public static Queue<Customer> getCustomers() {
        return customers;
    }

    public static void main(String[] args) {
        for (int i = 0; i < numberTransaction; i++) {
            transactionCounters[i] = new TransactionCounter();
        }
        // Thuc thi 1 ngay phuc vu (gia su chi dien ra trong 180s)
        System.out.println("Thoi gian SystemService phuc vu la: 180s");
        System.out.println("Hay ngoi doi 180s de chung toi thu thap duoc du lieu thong ke :)\n");

        // Tao ra 1 luong chay chuong trinh
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        Runnable task = () -> {
            // Khối lệnh cần dừng sau 180 giây
            MyRunnableOne r1 = new MyRunnableOne("Khach den SystemService de duoc phuc vu");
            MyRunnableTwo r2 = new MyRunnableTwo("Qua trinh phuc vu trong SystemService");

            Thread t1 = new Thread(r1);
            Thread t2 = new Thread(r2);

            t1.start();
            t2.start();
        };
        executor.schedule(task, 180, TimeUnit.SECONDS);
        executor.shutdown();
        // Lay ra cac du lieu thong ke duoc sau 1 ngay phuc vu
        try {
            executor.awaitTermination(5, TimeUnit.MINUTES);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println();
        statisticalData();
        System.exit(0);
    }

    static void statisticalData() {
        System.out.println("So khach den SystemService la: " + numberOfCustomerComeToSystemService);
        System.out.println(
                "So khach da duoc phuc vu la: " + (numberOfCustomerComeToSystemService - customers.size()) + "\n");
        for (int i = 0; i < transactionCounters.length; i++) {
            System.out.println("Information of transaction counter " + i + " is: ");
            System.out.println(transactionCounters[i].toStringInformation());
        }
    }

    static class MyRunnableOne implements Runnable {
        // Luong 1 thuc hien viec ngau nhien them 1 khach vao danh sach khach den
        // SystemService cho duoc phuc vu
        private String name;

        public MyRunnableOne(String name) {
            this.name = name;
        }

        public void run() {
            System.out.println("Thread " + name + " is running.");
            while (true) {
                try {
                synchronized (lock) {
                    lock.wait(50);
                    numberOfCustomerComeToSystemService++;
                    customers.add(new Customer(numberOfCustomerComeToSystemService));
                }
                } catch (InterruptedException e) {
                e.printStackTrace();
                }
            }
        }
    }

    static class MyRunnableTwo implements Runnable {
        // Luong 2 thuc hien cac cong viec phuc vu khach trong SystemService
        private String name;

        public MyRunnableTwo(String name) {
            this.name = name;
        }

        public void run() {
            System.out.println("Thread " + name + " is running.");
            while (true) {
                try {
                synchronized (lock) {
                    lock.wait(50);
                    transactionCounters[random.nextInt(numberTransaction)].getDoneACustomer();
                }
                } catch (InterruptedException e) {
                e.printStackTrace();
                }
            }
        }
    }
}
